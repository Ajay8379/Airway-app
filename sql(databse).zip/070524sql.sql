-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2024 at 07:40 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `anesthesia`
--

-- --------------------------------------------------------

--
-- Table structure for table `adddoctor`
--

CREATE TABLE `adddoctor` (
  `did` varchar(20) NOT NULL,
  `name` text NOT NULL,
  `phno` text NOT NULL,
  `pass` text NOT NULL,
  `gender` text NOT NULL,
  `speciality` text NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adddoctor`
--

INSERT INTO `adddoctor` (`did`, `name`, `phno`, `pass`, `gender`, `speciality`, `img`) VALUES
('kinkikoo1', 'kingh', '7897897787', '12334', 'male', 'malee', 'doctor_images/663737c7da8d0.jpg'),
('tyuhg56', 'king', '7897897785', '123', 'male', 'male', 'doctor_images/6638440a4c0f4.jpg'),
('tyuhg56', 'king', '7897897785', '123', 'male', 'male', 'doctor_images/6638440a4c0f4.jpg'),
('tyuhg56', 'king', '7897897785', '123', 'male', 'male', 'doctor_images/6638440a4c0f4.jpg'),
('singam', 'sun the sky', '7878787878', '1234', 'Male', 'knee', 'doctor_images/ED1BC6C4-1988-48BD-AC11-E07AC4CF6ACB.jpg'),
('adi', 'name', 'phno', 'passport2', 'mm', 'kkkk', 'doctor_images/6610fbf0c7469_Screenshot (22).png'),
('cvh', 'John Doe', '1234567890', 'password123', 'Male', 'Cardiology', 'doctor_images/cvh.jpg'),
('A213', 'Anshu', '789655454', 'A213', 'Male', 'ortho', 'doctor_images/6638433e9861f.jpg'),
('', 'kijk', '', '1234', 'Male', '', 'doctor_images/im1.png'),
('D127', 'kijk', '', '1234', 'Male', '', 'doctor_images/im1.png'),
('D127', 'kijk', '78978978990', '1234', 'Male', 'knoo', 'doctor_images/im1.png'),
('D126', 'kijk', '78978978990', '1234', 'Male', 'knoo', 'doctor_images/im1.png'),
('D124', 'kijk', '78978978990', '1234', 'Male', 'knoo', 'doctor_images/Screenshot (17).png'),
('saveetha123', 'kingg', '7897897788', '1234', 'female', '', 'doctor_images/im1.png'),
('saveetha1234', 'kingg', '7897897788', '1234', 'female', 'knee', 'doctor_images/im1.png'),
('saveetha12345', 'kingg', '7897897788', '1234', 'female', '', ''),
('saveetha1', 'Ajay', '7897897788', '12346', 'malee', 'ajayu', 'doctor_images/Screenshot (20).png'),
('saveetha10', 'kingg', '7897897788', '1234', 'female', 'kinkl', 'doctor_images/Screenshot (20).png'),
('saveetha11', 'kingg', '7897897788', '1234', 'female', 'kinkl', 'doctor_images/Screenshot (20).png'),
('saveet4', 'kingg', '7897897788', '1234', 'female', 'kinkl', 'doctor_images/im1.png'),
('kinkikoo178', 'kingg', '7897897788', '123346', 'female', 'knoh', 'doctor_images/Screenshot (24).png'),
('oop', 'kingg', '7897897788', '123346', 'female', 'knoh', 'doctor_images/Screenshot (22).png'),
('111', 'ajai', '1111111111', '111', 'M', 'ENT', 'doctor_images/5C7591A4-5133-466A-9203-2DE1AB8512AC.jpg'),
('567', 'Loks', '1111111111', '567', 'M', 'ENT', 'doctor_images/C53B4D24-2D60-4331-841E-9529E55A9A65.jpg'),
('678', 'thansin', '6767676767', '678', 'M', 'ENT', 'doctor_images/D2C2B005-E599-4541-AE9D-C67F5DA7BB2E.jpg'),
('679', 'thansin', '6767676767', '679', 'M', 'ENT', 'doctor_images/47594CFA-4FA4-47A0-9D98-B91C88F8F35E.jpg'),
('888', 'Sarada', '8888888888', '888', 'F', 'ortho', 'doctor_images/E5F95242-D57B-4233-ABF3-C2A255BB9B43.jpg'),
('999', 'Sarada', '8888888888', '999', 'F', 'ortho', 'doctor_images/E91F96C2-B039-4410-8D01-ECC97356D3F1.jpg'),
('989', 'loks1', '1111111111', '989', 'M', 'ent', 'doctor_images/838D279E-AA94-43E8-BA44-7CAE9925D2F1.jpg'),
('oopmm', 'kingg', '7897897788', '123346', 'female', 'knoh', 'doctor_images/Screenshot (22).png'),
('2234', 'nisha', '7878787879', '2234', 'F', 'ortho', 'doctor_images/9BE411BE-FFB1-4A57-942C-20134DEFDB6A.jpg'),
('87878', 'Dinesh', '7878787878', '87878', 'M', 'ent', 'doctor_images/180939D2-6D40-4922-99EA-67FB35723C63.jpg'),
('oopmmm', 'kingg', '7897897788', '123346', 'female', 'knoh', 'doctor_images/Screenshot (22).png'),
('oopmmmm', 'kingg', '7897897788', '123346', 'female', 'knoh', 'doctor_images/Screenshot (22).png'),
('5656', 'ajai', '7878787887', '5656', 'M', 'neuro', 'doctor_images/8B4AC30E-9C32-4A03-8A84-74BEE911162B.jpg'),
('671', 'Dhanush', '6676776767', '671', 'M', 'neuro', 'doctor_images/953BB661-8101-4CE0-9FEA-E669E23BD048.jpg'),
('672', 'Dhanush', '6676776767', '671', 'M', 'neuro', 'doctor_images/D843204F-4F06-44A0-8399-3393D28F00BD.jpg'),
('123', 'Anshu', '1111111111', '111', 'F', 'ENT', 'doctor_images/71A3FA02-1D64-4C98-AF62-8E6FA073FFC0.jpg'),
('6767', 'Sathish', '6767676767', '6767', 'F', 'neuro', 'doctor_images/5974CA14-FAA9-43F4-B849-D8447AE7F497.jpg'),
('1212', 'Saranya', '1212121212', '1212', 'F', 'neuro', 'doctor_images/DC6A252A-68B1-47D6-96E5-6A86BDB66928.jpg'),
('1234', 'ajay', '8989898989', '12345', 'maleh', 'kmuih', 'doctor_images/5B4B97E2-FEAF-48E2-ABDA-79FFEB29978C.jpg'),
('342', 'kmnk', '8956325655', '342', 'Male', 'ortho', 'doctor_images/342.jpg'),
('2134', 'klok', '7878787878', '2134', 'm', 'knee', 'doctor_images/B0704A14-C4B3-4221-8AE4-B4A6134C10BB.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `password`) VALUES
('saveetha123', 'welcome123');

-- --------------------------------------------------------

--
-- Table structure for table `adminprofile`
--

CREATE TABLE `adminprofile` (
  `id` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phno` varchar(12) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `age` varchar(4) NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adminprofile`
--

INSERT INTO `adminprofile` (`id`, `name`, `phno`, `email`, `gender`, `age`, `img`) VALUES
('kinkikoo1', 'king', '7897897787', 'ajay@123', 'male', '', 'admin/im1.png'),
('saveetha123', 'ajay kumar', '8989898987', '123@gmail.com', 'male', '21', 'admin/A48CDE70-8D86-4B03-B553-4CF48961B599.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `a_profile`
--

CREATE TABLE `a_profile` (
  `did` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `speciality` varchar(50) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `gmail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `a_profile`
--

INSERT INTO `a_profile` (`did`, `name`, `speciality`, `Gender`, `gmail`) VALUES
(',fpxiv', 'name', 'speciality', 'm/f', '@gmail.com'),
('123', 'name', 'speciality', 'm/f', '@gmail.com'),
('123h', 'name', 'speciality', 'm/f', '@gmail.com'),
('A123', 'name', 'speciality', 'm/f', '@gmail.com'),
('A12378', 'name', 'speciality', 'm/f', '@gmail.com'),
('aadi12', 'name', 'speciality', 'm/f', '@gmail.com'),
('Ajay12', 'name', 'speciality', 'm/f', '@gmail.com'),
('ajay123', 'name', 'speciality', 'm/f', '@gmail.com'),
('Am12', 'name', 'speciality', 'm/f', '@gmail.com'),
('Anu21', 'name', 'speciality', 'm/f', '@gmail.com'),
('Anu23', 'name', 'speciality', 'm/f', '@gmail.com'),
('Anuroop21', 'anu', 'knee', 'male', ''),
('Anuroop22', 'anu', 'knee', 'male', ''),
('B123', 'name', 'speciality', 'm/f', '@gmail.com'),
('bsndbx', 'name', 'speciality', 'm/f', '@gmail.com'),
('C123', 'name', 'speciality', 'm/f', '@gmail.com'),
('cavba558', 'name', 'speciality', 'm/f', '@gmail.com'),
('cdyju', 'name', 'speciality', 'm/f', '@gmail.com'),
('D123', 'name', 'speciality', 'm/f', '@gmail.com'),
('d12342', 'name', 'speciality', 'm/f', '@gmail.com'),
('D127', 'name', 'speciality', 'm/f', '@gmail.com'),
('Dha12', 'name', 'speciality', 'm/f', '@gmail.com'),
('dha342', 'name', 'speciality', 'm/f', '@gmail.com'),
('Dhanesh12', 'name', 'speciality', 'm/f', '@gmail.com'),
('doc1', 'name', 'speciality', 'm/f', '@gmail.com'),
('fhk56', 'name', 'speciality', 'm/f', '@gmail.com'),
('fjnv558', 'name', 'speciality', 'm/f', '@gmail.com'),
('funk', 'name', 'speciality', 'm/f', '@gmail.com'),
('gh566', 'name', 'speciality', 'm/f', '@gmail.com'),
('ghg5', 'name', 'speciality', 'm/f', '@gmail.com'),
('gopal1234', 'name', 'speciality', 'm/f', '@gmail.com'),
('h123', 'name', 'speciality', 'm/f', '@gmail.com'),
('hehxhdh', 'name', 'speciality', 'm/f', '@gmail.com'),
('hkjjhhh558', 'name', 'speciality', 'm/f', '@gmail.com'),
('k123', 'name', 'speciality', 'm/f', '@gmail.com'),
('Kim', 'name', 'speciality', 'm/f', '@gmail.com'),
('kinkikoo1', 'anu', 'knee', 'male', ''),
('knee1', 'name', 'speciality', 'm/f', '@gmail.com'),
('M67', 'name', 'speciality', 'm/f', '@gmail.com'),
('Mah43', 'name', 'speciality', 'm/f', '@gmail.com'),
('mah4321', 'name', 'speciality', 'm/f', '@gmail.com'),
('Male', 'name', 'speciality', 'm/f', '@gmail.com'),
('mjk112', 'name', 'speciality', 'm/f', '@gmail.com'),
('mjk113', 'name', 'speciality', 'm/f', '@gmail.com'),
('mjk114', 'name', 'speciality', 'm/f', '@gmail.com'),
('mklu1', 'name', 'speciality', 'm/f', '@gmail.com'),
('mnjk12', 'name', 'speciality', 'm/f', '@gmail.com'),
('N123', 'name', 'speciality', 'm/f', '@gmail.com'),
('nagma123', 'name', 'speciality', 'm/f', '@gmail.com'),
('Nare1234', 'name', 'speciality', 'm/f', '@gmail.com'),
('p12345', 'name', 'speciality', 'm/f', '@gmail.com'),
('pu1', 'name', 'speciality', 'm/f', '@gmail.com'),
('pu34', 'name', 'speciality', 'm/f', '@gmail.com'),
('qwewqf', 'name', 'speciality', 'm/f', '@gmail.com'),
('Sam21', 'name', 'speciality', 'm/f', '@gmail.com'),
('sam213', 'name', 'speciality', 'm/f', '@gmail.com'),
('Samsung', 'name', 'speciality', 'm/f', '@gmail.com'),
('Select Gender', 'name', 'speciality', 'm/f', '@gmail.com'),
('ssu122', 'name', 'speciality', 'm/f', '@gmail.com'),
('sus122', 'name', 'speciality', 'm/f', '@gmail.com'),
('welcome123', 'name', 'speciality', 'm/f', '@gmail.com'),
('welcome1234', 'name', 'speciality', 'm/f', '@gmail.com'),
('xgh45', 'name', 'speciality', 'm/f', '@gmail.com'),
('xvkk', 'name', 'speciality', 'm/f', '@gmail.com'),
('yehegvv2', 'name', 'speciality', 'm/f', '@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `doctorlogin`
--

CREATE TABLE `doctorlogin` (
  `id` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctorlogin`
--

INSERT INTO `doctorlogin` (`id`, `password`) VALUES
('pu1', 'pi123'),
('', ''),
('yehegvv2', '890uu'),
('ghg5', 'ghik'),
('funk', 'jhg'),
('Anu21', 'Anu21'),
('Ajay12', '123456'),
('Sam21', 'Sam12'),
('hehxhdh', 'hsbs'),
('bsndbx', 'bdxb'),
('welcome123', 's123'),
('welcome1234', 's123'),
('Male', '123'),
('Select Gender', ''),
('fjnv558', 'vvb888'),
('cavba558', 'habab859'),
('fhk56', 'yhbft698'),
('cdyju', 'yxshnc'),
('xvkk', 'vhk'),
('A123', 'a123'),
('xgh45', 'gjj57'),
('Ajay123', 'a1234'),
('Mah43', 'mah45'),
('ssu122', '24557'),
('pu34', 'pu54'),
('A12378', 'a123'),
('Dha12', 'd34D'),
('sam213', 'sam12'),
('M67', 'M567'),
('Anu23', 'Anu43'),
('p12345', 'p123'),
('gh566', 'hhgg5688'),
('N123', 'Naveen'),
('k123', 'kaberi123'),
('Am12', '1234'),
('mjk112', ''),
('mjk113', ''),
('mjk114', 'mjk113'),
('doc1', '1'),
('hkjjhhh558', 'gHbVs'),
('qwewqf', 'fade'),
('mah4321', 'mah4321'),
('aadi12', 'aadi123'),
('h123', '123'),
('123h', '123'),
(',fpxiv', ',gcuj'),
('mnjk12', 'mnjk12'),
('knee1', 'knee1'),
('mklu1', 'mklu1'),
('Samsung', 'Samsung'),
('Kim', 'Kim'),
('Anuroop21', 'anu76'),
('Anuroop22', 'anu76'),
('kinkikoo1', 'anu76'),
('123', '123'),
('B123', '1234'),
('C123', '1234'),
('D123', '1234'),
('D127', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `pdetails`
--

CREATE TABLE `pdetails` (
  `pid` varchar(20) NOT NULL,
  `name` text NOT NULL,
  `phno` text NOT NULL,
  `age` int(3) NOT NULL,
  `gender` text NOT NULL,
  `height` float NOT NULL,
  `weight` float NOT NULL,
  `bmi` float NOT NULL,
  `date` text NOT NULL,
  `img` text NOT NULL,
  `Crhm` int(3) NOT NULL,
  `Cwt` int(3) NOT NULL,
  `Cds` int(3) NOT NULL,
  `Cmmp` int(3) NOT NULL,
  `Cmoi` int(3) NOT NULL,
  `Ctmd` int(3) NOT NULL,
  `Ctmj` int(3) NOT NULL,
  `Cnm` int(3) NOT NULL,
  `Cnc` int(3) NOT NULL,
  `Cbmi` int(3) NOT NULL,
  `Ushb` int(3) NOT NULL,
  `Utt` int(3) NOT NULL,
  `Uttd` int(3) NOT NULL,
  `Uhd` int(3) NOT NULL,
  `Uhsk` int(3) NOT NULL,
  `Uesk` int(3) NOT NULL,
  `Uask` int(3) NOT NULL,
  `Upr` int(3) NOT NULL,
  `Uva` int(3) NOT NULL,
  `Ctotal` int(3) NOT NULL,
  `Utotal` int(3) NOT NULL,
  `total` int(3) NOT NULL,
  `atype` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pdetails`
--

INSERT INTO `pdetails` (`pid`, `name`, `phno`, `age`, `gender`, `height`, `weight`, `bmi`, `date`, `img`, `Crhm`, `Cwt`, `Cds`, `Cmmp`, `Cmoi`, `Ctmd`, `Ctmj`, `Cnm`, `Cnc`, `Cbmi`, `Ushb`, `Utt`, `Uttd`, `Uhd`, `Uhsk`, `Uesk`, `Uask`, `Upr`, `Uva`, `Ctotal`, `Utotal`, `total`, `atype`, `timestamp`) VALUES
('Jk56', 'aaaa', '8989898989', 1234, 'male', 5.9, 86, 2.47, '2024-02-17', 'img/Screenshot (23).png', 1, 5, 7, 4, 5, 6, 7, 8, 9, 10, 1, 0, 1, 1, 1, 1, 1, 3, 2, 24, 11, 35, 'Easy to moderate airway', '2024-05-05 11:37:49'),
('sush2368', 'Ajay', '8908908903', 20, 'Male', 1.8, 75, 23.15, '2024-04-12', 'img/6545EDE1-79D7-4A49-B46F-DB6DCDA4DE4B.jpg', 1, 4, 1, 3, 2, 1, 1, 1, 2, 3, 0, 1, 1, 0, 1, 1, 0, 3, 3, 19, 10, 29, 'Likely to be difficult airway', '2024-05-06 10:50:00'),
('kish23', 'name', 'Contact number', 0, 'm/f', 5.5, 56, 1.85, '2024-03-16', 'img/6629dcf14fcd2.jpg', 1, 1, 3, 3, 1, 2, 2, 3, 2, 3, 0, 1, 1, 0, 1, 1, 0, 4, 3, 21, 11, 32, 'Difficult airway', '2024-04-25 04:32:49'),
('kcjc', 'cjch', '6857586860', 85, 'Male', 5.5, 55, 1.82, '2024-03-14', 'img/6638431a5e2d9.jpg', 1, 1, 3, 3, 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 11, 4, 15, 'Normal airway', '2024-05-06 02:40:26'),
('ghkj569', 'fhnhg', '7893586558', 56, 'Male', 1.8, 100, 30.86, '2024-03-01', 'img/ghkj569.jpg', 1, 1, 1, 2, 1, 1, 1, 1, 1, 3, 0, 0, 1, 0, 1, 1, 1, 3, 2, 13, 9, 22, 'Likely to be difficult airway', '2024-03-14 10:10:15'),
('dhchhhhh', 'vhmh', '4556888668', 26, 'Male', 1.3, 58, 34.32, '2024-03-15', 'img/dhchhhhh.jpg', 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 2, 1, 3, 3, 6, 'Normal airway', '2024-03-14 10:34:44'),
('last1', 'last', '8995569885', 23, 'Female', 1.9, 1.8, 0.5, '2024-03-07', 'img/last1.jpg', 1, 1, 3, 2, 1, 2, 2, 1, 2, 2, 0, 1, 1, 0, 1, 1, 0, 2, 3, 17, 9, 26, 'Likely to be difficult airway', '2024-03-18 13:10:16'),
('milo', 'milo', '89098909', 89, 'male', 1.9, 67, 18.56, '09-09-2001', 'img/E5587807-36E4-472D-9CB4-C0E4506B5814.jpg', 1, 4, 1, 3, 0, 1, 2, 1, 2, 2, 0, 1, 1, 1, 0, 1, 0, 4, 2, 17, 10, 27, 'Likely to be difficult airway', '2024-03-21 16:26:29'),
('maj12', 'maj', '7897897894', 79, 'male', 1.9, 78, 21.607, '09-02-2024', 'img/98DE63E1-FCEC-435B-B87E-FED36FDEBB0C.jpg', 1, 4, 1, 2, 2, 1, 2, 1, 2, 3, 0, 1, 1, 1, 1, 1, 1, 4, 2, 19, 12, 31, 'Difficult Airway', '2024-03-30 03:43:27'),
('ppp00', 'gab', '884584548458', 45, 'male', 1.9, 85, 23.546, '02-02-2029', 'img/1C624216-B8B2-48F1-8F77-7BA21E43744E.jpg', 1, 4, 1, 1, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 3, 15, 10, 25, 'Likely to be difficult airway', '2024-03-30 05:17:42'),
('hu0852', 'hj', '8965369526', 23, 'Male', 1.9, 56, 15.51, '2024-03-08', 'img/hu0852.jpg', 2, 1, 4, 1, 2, 2, 1, 2, 1, 3, 0, 1, 1, 1, 0, 1, 1, 4, 3, 19, 12, 31, 'Difficult airway', '2024-03-30 08:59:34'),
('hk569', 'hj', '7895688559', 52, 'Male', 1.8, 82, 25.31, '2024-04-04', 'img/hk569.jpg', 1, 2, 2, 1, 1, 2, 2, 3, 2, 2, 0, 1, 1, 0, 0, 0, 0, 4, 3, 18, 9, 27, 'Likely to be difficult airway', '2024-04-01 04:45:40'),
('kim8', 'Kim', '7878787878', 21, 'male', 1.9, 43, 11.911, '09-09-2024', 'img/031058C4-5646-40E2-853B-D864A18B77EE.jpg', 1, 5, 1, 3, 2, 2, 1, 2, 2, 1, 0, 1, 1, 1, 1, 1, 1, 4, 2, 20, 12, 32, 'Difficult Airway', '2024-04-01 09:06:28'),
('s123', 'sami', '7896509699', 23, 'Male', 1.9, 86, 23.82, '2024-04-13', 'img/s123.jpg', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 3, 2, 21, 10, 31, 'Difficult airway', '2024-04-07 16:26:59'),
('D127', 'kijk', '78978978990', 1234, 'Male', 0, 88, 9.8, '09-09-2024', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-08 04:12:41'),
('D120', 'kijk', '78978978990', 1234, 'Male', 0, 88, 9.8, '09-09-2024', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-08 04:13:39'),
('D120', 'kijk', '78978978990', 1234, 'Male', 0, 88, 9.8, '09-09-2024', 'img/im1.png', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-08 04:14:09'),
('A123890', 'gvg', '', 23, 'male', 1.9, 21, 12, '09-09-2023', 'img/im1.png', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-12 08:29:18'),
('A123890', 'gvg', '1237899000', 23, 'male', 1.9, 21, 12, '09-09-2023', 'img/im1.png', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-12 08:29:49'),
('A123890', 'gvg', '1237899000', 23, 'male', 1.9, 21, 12, '09-09-2023', 'img/im1.png', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-12 08:39:57'),
('A123890', 'gvg', '1237899000', 23, 'male', 1.9, 21, 12, '09-09-2023', 'img/im1.png', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-12 08:44:01'),
('A123899', 'gvg', '1237899000', 23, 'male', 1.9, 21, 12, '09-09-2023', 'img/im1.png', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-12 08:47:25'),
('A123899m', 'gvg', '1237899000', 23, 'male', 1.9, 21, 12, '09-09-2023', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-23 05:42:01'),
('A123899mu', 'king the land', '7897897787', 89, 'male', 1.9, 21, 12, '09-09-2023', 'img/271F1796-BE05-42D4-805A-838EC021A23A.jpg', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-25 03:10:38'),
('lpo0', 'king', '7897897787', 89, 'male', 3.7, 45, 12, '09-09-2024', 'img/Screenshot (23).png', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-25 03:23:03'),
('lpo09', 'king', '7897897787', 89, 'male', 3.7, 45, 12, '09-09-2024', 'img/Screenshot (23).png', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-25 03:26:07'),
('lpo092', 'king', '7897897787', 89, 'male', 3.7, 45, 12, '09-09-2024', 'img/Screenshot (23).png', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-25 03:26:42'),
('lpo0921', 'king', '7897897787', 89, 'male', 3.7, 45, 12, '09-09-2024', 'img/Screenshot (23).png', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-25 03:26:59'),
('6767', '7878788878', '7878788878', 78, 'Male', 6, 78, 2.17, '2024-04-05', 'img/7C473436-DF14-4289-8365-9711593B798C.jpg', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-25 04:28:41'),
('5656', '5656565656', '5656565656', 56, 'Male', 5, 54, 2.16, '2024-04-19', 'img/4F552B5D-0548-4805-A67D-125DF291DE37.jpg', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-25 04:35:55'),
('4456gyhhyjhj', '5656656666', '5656656666', 56, 'm', 1.9, 55, 15.24, '2024-04-19', 'img/3AC570E5-F6EC-45C0-BA27-B109F3D27DAA.jpg', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-25 04:41:42'),
('889', '8989898989', '8989898989', 89, 'Male', 7, 78, 1.59, '2024-04-03', 'img/BE5DC024-CB25-46CB-B834-A9E5A4681732.jpg', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-25 04:55:23'),
('ttyy66', '1234567890', '1234567890', 34, 'm', 5, 50, 2, '2024-04-10', 'img/7F81FA72-20A6-400C-81C1-326F85C748B7.jpg', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '2024-04-25 05:43:38'),
('hyu77', '2345677777', '2345677777', 76, 'm', 5.8, 34, 1.01, '2024-04-03', 'img/1B0075DA-FE43-4F45-B149-4950479636CA.jpg', 1, 0, 0, 0, 0, 0, 0, 3, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 15, 35, 'Difficult airway', '2024-04-25 06:10:13'),
('p09oii', '1234567890', '1234567890', 77, 'm', 5.9, 45, 1.29, '2024-04-10', 'img/33DCD8D5-7B9F-4EB9-B583-B113FA8BB7B8.jpg', 2, 3, 2, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, '0', '2024-04-25 05:55:20'),
('sdfghjk', '1234567890', '1234567890', 90, 'm', 9, 99, 1.22, '2024-04-19', 'img/AECDD74F-EFD3-4A58-BE4B-527EB0E780C6.jpg', 2, 5, 2, 3, 2, 2, 2, 3, 2, 3, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, '0', '2024-04-25 06:13:24'),
('nmhjkhj', 'Ajay', '1234567890', 78, 'F', 9, 76, 0.94, '2024-04-03', 'img/F927ACF8-BA54-465E-89FB-8E235E6F9887.jpg', 2, 5, 2, 3, 2, 2, 1, 3, 2, 3, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, '0', '2024-05-05 06:39:05'),
('123456', '1234567890', '1234567890', 0, 'dasdas', 0, 0, 0, '2024-05-09', 'img/CD70A345-F24C-4C36-BB92-D82FB3F8378F.jpg', 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 7, 6, 13, 'Normal Airway', '2024-05-04 16:18:33'),
('3242', '7897897890', '7897897890', 65, 'male', 3.7, 65, 4.75, '2024-05-10', 'img/63080BB3-2F52-42BF-83CF-DAB7794FE23A.jpg', 2, 5, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 15, 8, 23, 'Likely to be difficult airway', '2024-05-05 06:42:28'),
('cufuf', 'dudfu', '5645767688', 86, 'Female', 5.9, 56, 1.61, '2024-05-23', 'img/cufuf.jpg', 2, 1, 5, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 15, 8, 23, 'Likely to be difficult airway', '2024-05-05 07:16:21'),
('12354', 'Kingh', '7896543255', 23, 'Male', 4.8, 89, 3.86, '2024-05-23', 'img/12354.jpg', 2, 1, 4, 1, 2, 2, 2, 2, 1, 3, 0, 1, 1, 1, 1, 1, 1, 2, 3, 20, 11, 31, 'Difficult airway', '2024-05-06 02:42:25'),
('14321432', '2132313213', '2132313213', 23, 'male', 23, 23, 0.04, '2024-05-08', 'img/B27ABA46-6D35-400C-B0D9-0B6CE4E76ECF.jpg', 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 7, 6, 13, 'Normal Airway', '2024-05-06 08:01:32'),
('2345671', '3456767777', '3456767777', 21, 'm', 7.9, 89, 1.43, '2024-05-15', 'img/4D33C1CE-F0FD-4847-B382-A04A82AC1615.jpg', 2, 5, 1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 1, 1, 1, 0, 0, 3, 2, 0, 0, 0, '0', '2024-05-06 08:15:35'),
('7997', '9898989898', '9898989898', 98, 'm', 9.8, 45, 0.47, '2024-05-09', 'img/869A4B4F-43DD-4D6A-8AA4-B1329BC264B2.jpg', 2, 5, 2, 2, 2, 2, 2, 3, 2, 3, 0, 1, 1, 1, 1, 1, 0, 3, 2, 25, 10, 35, 'Difficult Airway', '2024-05-06 08:37:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminprofile`
--
ALTER TABLE `adminprofile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `a_profile`
--
ALTER TABLE `a_profile`
  ADD PRIMARY KEY (`did`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
