<?php
// Include your database connection file
require "conn.php";

// Check if the necessary parameters are provided
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the JSON input
    $jsonInput = file_get_contents("php://input");

    // Decode JSON data into an associative array
    $postData = json_decode($jsonInput, true);

    // Check if JSON decoding was successful
    if ($postData !== null) {
        // Sanitize input data to prevent SQL injection
        $id = $postData['id'];
        $name = $postData['name'];
        $gender = $postData['gender'];
        $age = $postData['age'];
        $height = $postData['height'];
        $weight = $postData['weight'];
        $phno = $postData['phno'];
        $bmi = $postData['bmi'];
        $dob = $postData['dob'];

        // Directory to save uploaded profile pictures
        $uploadDirectory = "img/" . $id . '.jpg';

        // Get the uploaded file details
        $profilePicBase64 = $postData['profile_pic'];
        $profilePicBinary = base64_decode($profilePicBase64);

        // Save the image
        if (file_put_contents($uploadDirectory, $profilePicBinary)) {
            // Update the database with the new information including the profile picture path
            $profilePicPath = $uploadDirectory;
            $query = "INSERT INTO pdetails (pid, name, phno, age, gender, height, weight, bmi, date, img)
                      VALUES ('$id', '$name', '$phno', '$age', '$gender', '$height', '$weight', '$bmi', '$dob', '$profilePicPath')";

            if (mysqli_query($conn, $query)) {
                echo json_encode(['status' => 'success']);
            } else {
                echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to save the image']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid JSON format']);    
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}

// Close the database connection
mysqli_close($conn);
?>
