<?php
// Include your database connection file
require "conn.php";
date_default_timezone_set('Asia/Kolkata');

// Check if all necessary parameters are provided via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input data to prevent SQL injection
    $id = $_POST['id'];
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $height = $_POST['height'];
    $weight = $_POST['weight'];
    $phno = $_POST['phno'];
    $bmi = $_POST['bmi'];
    $dob = $_POST['dob'];
    
    $currentDate = date("Y-m-d H:i:s");

    // Check if the ID already exists in the database
    $checkQuery = "SELECT * FROM pdetails WHERE pid = '$id'";
    $result = mysqli_query($conn, $checkQuery);

    if (mysqli_num_rows($result) > 0) {
        // ID already exists in the database
        echo json_encode(['status' => '2', 'message' => 'ID already exists']);
    } else {
        // Function to upload image and return the paths
        function uploadImages($fieldName) {
            global $targetDirectory;
            $result = [];
            $targetDirectory = "img/";
            // Check if the field name exists and if it's an array
            if (isset($_FILES[$fieldName]) && is_array($_FILES[$fieldName]["name"])) {
                foreach ($_FILES[$fieldName]["name"] as $key => $value) {
                    $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"][$key]);
                    if (move_uploaded_file($_FILES[$fieldName]["tmp_name"][$key], $targetFile)) {
                        $result[] = $targetFile;
                    } else {
                        $result[] = null;
                    }
                }
            } elseif (isset($_FILES[$fieldName])) {
                // If there's only one file, treat it as an array
                $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"]);
                if (move_uploaded_file($_FILES[$fieldName]["tmp_name"], $targetFile)) {
                    $result[] = $targetFile;
                } else {
                    $result[] = null;
                }
            }

            return $result;
        }

        // Check if profile picture is uploaded
        if (isset($_FILES["profile_pic"])) {
            $profilePicPaths = uploadImages("profile_pic");

            if (!empty($profilePicPaths)) {
                // Choose the first image path if multiple files are uploaded
                $profilePicPath = $profilePicPaths[0];

                // Insert new record into the database
                $query = "INSERT INTO pdetails (pid, name, phno, age, gender, height, weight, bmi, date, img, Crhm, Cwt, Cds, Cmmp, Cmoi, Ctmd, Ctmj, Cnm, Cnc, Cbmi, Ushb, Utt, Uttd, Uhd, Uhsk, Uesk, Uask, Upr, Uva, Ctotal, Utotal, total, atype, timestamp)
                VALUES ('$id', '$name', '$phno', '$age', '$gender', '$height', '$weight', '$bmi', '$dob', '$profilePicPath', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0','0','0','$currentDate')";


                // Execute the query
                if (mysqli_query($conn, $query)) {
                    echo json_encode(['status' => '1','message' => 'ID created successfully']);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Failed to execute query']);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Failed to save the image']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Profile picture not uploaded']);
        }
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Missing or invalid parameters']);
}

// Close the database connection
mysqli_close($conn);
?>
